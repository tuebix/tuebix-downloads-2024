# Einführung in OpenSCAD
## Tübix 2024
### von Torsten Kockler

#### Links:

Dokumentation zu OpenSCAD:
https://openscad.org/documentation.html

OpenSCAD User Manual:
https://en.wikibooks.org/wiki/OpenSCAD_User_Manual

#### Weitere im Vortrag gezeigte Software:

Inkscape:
https://inkscape.org/de/

Prusa Slicer:
https://www.prusa3d.com/de/page/prusaslicer_424/


