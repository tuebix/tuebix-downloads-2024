#!/bin/bash

openscad Grundformen.scad Transform.scad Bool.scad Fablab-Logo.scad Turm.scad Hull.scad Minkowski.scad Variablen.scad 2D.scad Donut.scad Laeufer.scad Ente.scad Springer.scad Schachbrett.scad Schach.scad Tuebix_2024.scad &
